package com.example.notetaking

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException


class NewUserActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_user)

        // Inside onCreate method
        val submitNewUserButton = findViewById<Button>(R.id.submitNewUserButton)
        submitNewUserButton.setOnClickListener {

            // Retrieve user details from edit text fields
            val firstNameEditText = findViewById<EditText>(R.id.firstNameEditText)
            val lastNameEditText = findViewById<EditText>(R.id.lastNameEditText)
            val emailEditText = findViewById<EditText>(R.id.emailEditText)
            val passwordEditText = findViewById<EditText>(R.id.passwordEditText) // New
            val firstName = firstNameEditText.text.toString()
            val lastName = lastNameEditText.text.toString()
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString() // New

            // Call the method to create a new user
            createUser(firstName, lastName, email, password) // Updated function call

            // Launch the FinishRegisterActivity
            val intent = Intent(this@NewUserActivity, FinishRegisterActivity::class.java)
            // Launch the FinishRegisterActivity
            intent.putExtra("email",email)
            intent.putExtra("password",password)
            startActivity(intent)
        }
    }

    private fun createUser(firstName: String, lastName: String, email: String, password: String) { // Updated function signature
        // Define the URL for user creation.
        val client = OkHttpClient()

        // Define the JSON body with variables
        val json = """
            {
                "method": "createAccount",
                "last_name": "$lastName",
                "first_name": "$firstName",
                "email": "$email",
                "password": "$password", // New
                "extra": "//Your own custom information"
            }
        """.trimIndent()
//        val json = """
//            {
//                "method": "createAccount",
//                "last_name": "ahmed",
//                "first_name": "wanas",
//                "email": "$email",
//                "password": "Amhed@2023", // New
//                "extra": "//Your own custom information"
//            }
//        """.trimIndent()

        // Define the request body
        val requestBody = json.toRequestBody("application/json; charset=utf-8".toMediaType())

        // Define the request with correct URL
        val request = Request.Builder()
            .url("http://10.0.2.2:6000/") // Corrected URL
            .post(requestBody)
            .build()

        // Make the request asynchronously
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
                Log.d("work", "Failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { Log.d("work", it) }
            }
        })
    }
}