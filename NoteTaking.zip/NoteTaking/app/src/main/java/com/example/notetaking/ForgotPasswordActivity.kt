package com.example.notetaking

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.io.IOException

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody


class ForgotPasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        // Inside onCreate method val signInButton = findViewById<Button>(R.id.signInButton)
        val submitPasswordResetButton = findViewById<Button>(R.id.submitPasswordResetButton)
        submitPasswordResetButton.setOnClickListener {

            // Retrieve email from edit text field
            val emailEditText = findViewById<EditText>(R.id.emailEditText)
            val email = emailEditText.text.toString()

            // Call the method to initiate password reset
            initiatePasswordReset(email)
        }

    }

    private fun initiatePasswordReset(email: String) {
        // Define the URL for password reset.
        val client = OkHttpClient()

        // Define the JSON body
        val json = """
            {
                "email": "$email",
                "method": "forgotPassword"
            }
        """.trimIndent()


        // Define the request body
        val requestBody = json.toRequestBody("application/json".toMediaType())


        // Define the request
        val requests = Request.Builder()
            .url("http://10.0.2.2:6000")
            .post(requestBody)
            .build()


        // Make the request asynchronously
        client.newCall(requests).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                e.printStackTrace()
                Log.d("work", e.toString())
                Log.d("work","failed")
            }


            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                response.body?.string()?.let { Log.d("work", it) }
            }
        })








    }


    private fun saveTokenLocally(token: String) {
        // Save the token to local storage for future use
    }
}




