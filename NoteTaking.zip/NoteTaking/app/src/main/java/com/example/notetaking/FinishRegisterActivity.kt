package com.example.notetaking
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class FinishRegisterActivity : AppCompatActivity() {
    private lateinit var messageTextView: TextView
    private lateinit var finishRegistrationButton: Button
    private lateinit var tempPasswordEditText: EditText
    private lateinit var email: String // Added email variable to store user's email
    private lateinit var password: String // Added email variable to store user's email

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_finish_register)

        messageTextView = findViewById(R.id.messageTextView)
        finishRegistrationButton = findViewById(R.id.finishRegistrationButton)
        tempPasswordEditText = findViewById(R.id.tempPasswordEditText)

        messageTextView.text = "Please enter the temporary password that was sent to you."

        // Retrieve email from intent extras
        email = intent.getStringExtra("email") ?: ""
         password = intent.getStringExtra("password") ?: ""

        finishRegistrationButton.setOnClickListener {
            val enteredTempPassword = tempPasswordEditText.text.toString()
            if (enteredTempPassword.isNotEmpty()) {
                registerAccount(enteredTempPassword)
            } else {
                Toast.makeText(this, "Please enter the temporary password.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun registerAccount(tempPassword: String) {
        val client = OkHttpClient()

        // Prepare the JSON request body
        val json = """
        {
            "method": "registerAccount",
            "password": "$password",
            "temp_password": "$tempPassword",
            "email": "$email"
        }
        """.trimIndent()
        Log.d("work",tempPassword)
        Log.d("work",email)
        val requestBody = json.toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url("http://10.0.2.2:6000/") // Adjust the URL as needed
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
                runOnUiThread {
                    Toast.makeText(this@FinishRegisterActivity, "Failed to register account. Please try again.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    // Registration successful
                    runOnUiThread {
                        Toast.makeText(this@FinishRegisterActivity, "Account registered successfully!", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@FinishRegisterActivity, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                } else {
                    // Registration failed
                    runOnUiThread {
                        Toast.makeText(this@FinishRegisterActivity, "Failed to register account. Please try again.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }
}
