package com.example.notetaking

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle


import android.util.Log
import okhttp3.*




import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
class SignInActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        // Assuming you have UI elements for username and password fields
        val username = "example_username"
        val password = "example_password"

        authenticateUser(username, password)
    }

    private fun authenticateUser(username: String, password: String) {
        // Define the URL for login.
        val client = OkHttpClient()

        // Define the JSON body
        val json = """
        {
            "username": "$username",
            "password": "$password"
        }
        """.trimIndent()

        // Define the request body
        val requestBody = json.toRequestBody("application/json".toMediaType())

        // Define the request
        val request = Request.Builder()
            .url("http://10.0.2.2:6000/") // Change the URL to your authentication endpoint
            .post(requestBody)
            .build()

        // Make the request asynchronously
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
                Log.d("SignInActivity", "Authentication failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val token = response.body?.string() ?: ""
                saveTokenLocally(token)
            }
        })
    }

    private fun saveTokenLocally(token: String) {
        // Save the token to local storage for future use
        Log.d("SignInActivity", "Token received: $token")
        // Implement your logic to save the token locally
    }
}
